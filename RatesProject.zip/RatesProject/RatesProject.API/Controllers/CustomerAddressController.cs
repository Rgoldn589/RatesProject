﻿using Azure.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RatesProject.API.DataContext;
using RatesProject.API.Requests;
using RatesProject.Models;
using System.Reflection.Emit;

namespace RatesProject.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerAddressController : ControllerBase
    {
        private readonly RatesProjectWebAppContext _context;
        public CustomerAddressController(RatesProjectWebAppContext context)
        {
            _context = context;
        }


        [HttpGet("GetCustomerAddresses")]
        public async Task<IActionResult> GetCustomersAddresses()
        {
            try
            {
                var customersAddresses = await _context.Address.ToListAsync();

                var customerAddressesJson = JsonConvert.SerializeObject(customersAddresses, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(customerAddressesJson);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetCustomerAddress")]
        public async Task<IActionResult> GetCustomerAddress(GetCustomerDataRequest request)
        {
            try
            {
                var customerAddress = await _context.Address
                        .Include(c => c.Customer)
                        .Include(at => at.AddressType)
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

               customerAddress.AddressTypes = await  _context.AddressType.ToListAsync();   

                var customerAddressJson = JsonConvert.SerializeObject(customerAddress, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(customerAddressJson);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet ("GetAddressTypes")]
        public async Task<IActionResult> GetAddressTypes()
        {
            try
            {
                var addressTypes = await _context.AddressType.ToListAsync();

                var addressTypesJson = JsonConvert.SerializeObject(addressTypes, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(addressTypesJson);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("UpdateCustomerAddress")]
        public async Task<IActionResult> UpdateCustomerAddress(UpdateCustomerAddressRequest request)
        {
            try
            {
                var customerAddress = await _context.Address
                .FirstOrDefaultAsync(e => e.Id.Equals(request.Id));

                if (customerAddress == null)
                {
                    await _context.Address.AddAsync(new Address()
                    {
                        Id = request.Id,
                        AddressTypeId = request.AddressTypeId,
                        CustomerId = request.CustomerId,
                        StreetAddress = request.StreetAddress,
                        City = request.City,
                        State = request.State,
                        ZipCode = request.ZipCode,
                        StartDate = request.StartDate,
                        EndDate = request.EndDate
                    });
                }
                else
                {
                    customerAddress.AddressTypeId = request.AddressTypeId;
                    customerAddress.CustomerId = request.CustomerId;
                    customerAddress.StreetAddress = request.StreetAddress;
                    customerAddress.City = request.City;
                    customerAddress.State = request.State;
                    customerAddress.ZipCode = request.ZipCode;
                    customerAddress.StartDate = request.StartDate;
                    customerAddress.EndDate = request.EndDate;
                }

                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("DeleteCustomerAddress")]
        public async Task<IActionResult> DeleteCustomerAddress(GetCustomerDataRequest request)
        {
            try
            {
                var customerAddress = await _context.Address
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                if (customerAddress == null)
                {
                    return NotFound("fail");
                }

                _context.Address.Remove(customerAddress);
                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
