﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RatesProject.API.DataContext;
using RatesProject.API.Requests;
using RatesProject.Models;

namespace RatesProject.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly RatesProjectWebAppContext _context;

        public CustomerController(RatesProjectWebAppContext context)
        {
            _context = context;
        }

        [HttpGet("GetCustomers")]
        public async Task<IActionResult> GetCustomers()
        {
            try
            {
                var customers = await _context.Customer.ToListAsync();

                var customersJson = JsonConvert.SerializeObject(customers, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(customersJson);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetCustomer")]
        public async Task<IActionResult> GetCustomer(GetCustomerDataRequest request)
        {
            try
            {
                var customer = await _context.Customer
                    .Include(a => a.Addresses)
                        .ThenInclude(at => at.AddressType)
                    .Include(p => p.Phone)
                        .ThenInclude(t => t.PhoneType)
                    .Include(r => r.CustomerRates)
                        .ThenInclude(cr => cr.RateType)
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                var customerJson = JsonConvert.SerializeObject(customer, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(customerJson);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("UpdateCustomer")]
        public async Task<IActionResult> UpdateCustomer(UpdateCustomerRequest request)
        {
            try
            {
                var customer = await _context.Customer
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                if (customer == null)
                {
                    await _context.Customer.AddAsync(new Customer()
                    {
                        Id = request.ID,
                        FirstName = request.FirstName,
                        LastName = request.LastName,
                        StartDate = request.StartDate,
                        EndDate = request.EndDate
                    });
                }
                else
                {
                    customer.FirstName = request.FirstName;
                    customer.LastName = request.LastName;
                    customer.StartDate = request.StartDate;
                    customer.EndDate = request.EndDate;
                }

                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("DeleteCustomer")]
        public async Task<IActionResult> DeleteCustomer(GetCustomerDataRequest request)
        {
            try
            {
                var employee = await _context.Customer
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                if (employee == null)
                {
                    return NotFound("fail");
                }

                _context.Customer.Remove(employee);
                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
