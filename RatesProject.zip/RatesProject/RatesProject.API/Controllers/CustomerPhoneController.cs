﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RatesProject.API.DataContext;
using RatesProject.API.Requests;
using RatesProject.Models;

namespace RatesProject.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerPhoneController : ControllerBase
    {
        private readonly RatesProjectWebAppContext _context;
        public CustomerPhoneController(RatesProjectWebAppContext context)
        {
            _context = context;
        }


        [HttpGet("GetCustomerPhones")]
        public async Task<IActionResult> GetCustomersPhones()
        {
            try
            {
                var customerPhones = await _context.Phone.ToListAsync();

                var customerPhonesJson = JsonConvert.SerializeObject(customerPhones, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(customerPhonesJson);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetCustomerPhone")]
        public async Task<IActionResult> GetCustomer(GetCustomerDataRequest request)
        {
            try
            {
                var customerPhone = await _context.Phone
                        .Include(x => x.Customer)
                        .Include(pt => pt.PhoneType)
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                customerPhone.PhoneTypes = await _context.PhoneType.ToListAsync();

                var customerPhoneJson = JsonConvert.SerializeObject(customerPhone, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(customerPhoneJson);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetPhoneTypes")]
        public async Task<IActionResult> GetPhoneTypes()
        {
            try
            {
                var PhoneTypes = await _context.PhoneType.ToListAsync();

                var PhoneTypesJson = JsonConvert.SerializeObject(PhoneTypes, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(PhoneTypesJson);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("UpdateCustomerPhone")]
        public async Task<IActionResult> UpdateCustomerPhone(UpdateCustomerPhoneRequest request)
        {
            try
            {
                var customerPhone = await _context.Phone
                .FirstOrDefaultAsync(e => e.Id.Equals(request.Id));

                if (customerPhone == null)
                {
                    await _context.Phone.AddAsync(new Phones()
                    {
                        Id = request.Id,
                        PhoneTypeId = request.PhoneTypeId,
                        CustomerId = request.CustomerId,
                        PhoneNumber = request.PhoneNumber.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", ""),
                        CreatedDate = DateTime.Now
                    });
                }
                else
                {
                    customerPhone.PhoneTypeId = request.PhoneTypeId;
                    customerPhone.CustomerId = request.CustomerId;
                    customerPhone.PhoneNumber = request.PhoneNumber.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "");
                }

                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("DeleteCustomerPhone")]
        public async Task<IActionResult> DeleteCustomer(GetCustomerDataRequest request)
        {
            try
            {
                var customerPhone = await _context.Phone
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                if (customerPhone == null)
                {
                    return NotFound("fail");
                }

                _context.Phone.Remove(customerPhone);
                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
