﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RatesProject.API.DataContext;
using RatesProject.API.Requests;
using RatesProject.Models;

namespace RatesProject.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerRateController : ControllerBase
    {
        private readonly RatesProjectWebAppContext _context;
        public CustomerRateController(RatesProjectWebAppContext context)
        {
            _context = context;
        }

        [HttpGet("GetCustomerRates")]
        public async Task<IActionResult> GetCustomersRates()
        {
            try
            {
                var customerRates = await _context.CustomerRates.ToListAsync();
                  
                var customerRatesJson = JsonConvert.SerializeObject(customerRates, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });


              
                return Ok(customerRatesJson);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetCustomerRate")]
        public async Task<IActionResult> GetCustomer(GetCustomerDataRequest request)
        {
            try
            {
                var customerRate = await _context.CustomerRates
                        .Include(c => c.Customer)
                        .Include(r => r.RateType)
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                customerRate.RateTypes = await _context.RateType.ToListAsync();

                var customerRateJson = JsonConvert.SerializeObject(customerRate, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(customerRateJson);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetRateTypes")]
        public async Task<IActionResult> GetRateTypes()
        {
            try
            {
                var RateTypes = await _context.RateType.ToListAsync();

                var RateTypesJson = JsonConvert.SerializeObject(RateTypes, Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

                return Ok(RateTypesJson);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("UpdateCustomerRate")]
        public async Task<IActionResult> UpdateCustomerPhone(UpdateCustomerRateRequest request)
        {
            try
            {
                var customerRate = await _context.CustomerRates
                .FirstOrDefaultAsync(e => e.Id.Equals(request.Id));

                if (customerRate == null)
                {
                    await _context.CustomerRates.AddAsync(new CustomerRate()
                    {
                        Id = request.Id,
                        RateTypeId = request.RateTypeId,
                        CustomerId = request.CustomerId,
                        RateName = request.RateName,
                        RateAmount = request.RateAmount,
                        CreatedDate = DateTime.Now
                    });
                }
                else
                {
                    customerRate.RateTypeId = request.RateTypeId;
                    customerRate.CustomerId = request.CustomerId;
                    customerRate.RateName = request.RateName;
                    customerRate.RateAmount = request.RateAmount;
                }

                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("DeleteCustomerRate")]
        public async Task<IActionResult> DeleteCustomer(GetCustomerDataRequest request)
        {
            try
            {
                var customerRate = await _context.CustomerRates
                    .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

                if (customerRate == null)
                {
                    return NotFound("fail");
                }

                _context.CustomerRates.Remove(customerRate);
                await _context.SaveChangesAsync();
                return Ok("Success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
