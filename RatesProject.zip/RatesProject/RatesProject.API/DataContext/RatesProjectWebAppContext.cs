﻿using Microsoft.EntityFrameworkCore;
using RatesProject.Models;

namespace RatesProject.API.DataContext
{
    public class RatesProjectWebAppContext:DbContext
    {
        public RatesProjectWebAppContext(DbContextOptions<RatesProjectWebAppContext> options)
            : base(options)
        {
        }
        public DbSet<Customer> Customer { get; set; } = default!;
        public DbSet<CustomerRate> CustomerRates { get; set; } = default!;
        public DbSet<RateType> RateType { get; set; } = default!;
        public DbSet<Address> Address { get; set; } = default!;
        public DbSet<AddressType> AddressType { get; set; } = default!;
        public DbSet<Phones> Phone { get; set; } = default!;
        public DbSet<PhoneType> PhoneType { get; set; } = default!;
    }
}
