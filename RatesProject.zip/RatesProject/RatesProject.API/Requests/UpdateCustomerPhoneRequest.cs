﻿using System.ComponentModel.DataAnnotations;

namespace RatesProject.API.Requests
{
    public class UpdateCustomerPhoneRequest
    {
        public Guid Id { get; set; }
        public Guid CustomerId { get; set; }
        public Guid PhoneTypeId { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
