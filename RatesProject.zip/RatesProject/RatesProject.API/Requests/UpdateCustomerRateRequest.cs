﻿using System.ComponentModel.DataAnnotations;

namespace RatesProject.API.Requests
{
    public class UpdateCustomerRateRequest
    {
        public Guid Id { get; set; }
        public Guid CustomerId { get; set; }
        public Guid RateTypeId { get; set; }
        public string RateName { get; set; } = null!;
        public decimal RateAmount { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}
