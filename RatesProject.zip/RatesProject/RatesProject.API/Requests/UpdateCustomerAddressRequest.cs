﻿using System.ComponentModel.DataAnnotations;

namespace RatesProject.API.Requests
{
    public class UpdateCustomerAddressRequest
    {
        public Guid Id { get; set; }
        public Guid CustomerId { get; set; }
        public Guid AddressTypeId { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; } 
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
