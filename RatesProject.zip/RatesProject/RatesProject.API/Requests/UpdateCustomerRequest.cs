﻿using System.ComponentModel.DataAnnotations;

namespace RatesProject.API.Requests
{
    public class UpdateCustomerRequest
    {

        public Guid ID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
