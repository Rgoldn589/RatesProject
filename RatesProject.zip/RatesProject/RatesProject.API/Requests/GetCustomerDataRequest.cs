﻿namespace RatesProject.API.Requests
{
    public class GetCustomerDataRequest
    {
        public Guid ID { get; set; }
    }
}
