﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class AddressType
{
    public Guid Id { get; set; }


    [Display(Name = "Description")]
    public string AddressTypeDescription { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();
}
