﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class AddressType
{
    public Guid Id { get; set; }


    [Display(Name = "Description")]
    public string AddressTypeDescription { get; set; } = null!;

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Required]
    public DateTime StartDate { get; set; }

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    public DateTime? EndDate { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (EndDate < StartDate)
        {
            yield return new ValidationResult(
                errorMessage: "End Date must be greater than Start Date",
                memberNames: new[] { "EndDate" }
           );
        }
    }

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();
}
