﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class Address : IValidatableObject
{
    public Guid Id { get; set; }

    public Guid CustomerId { get; set; }

    public Guid AddressTypeId { get; set; }

    [Display(Name = "Street")]
    [Required]
    public string StreetAddress { get; set; } = null!;

    [Required]
    public string City { get; set; } = null!;

    [Required]
    public string State { get; set; } = null!;

    [Required]
    public string ZipCode { get; set; } = null!;

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "Start Date")]
    [Required]
    public DateTime StartDate { get; set; }

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "End Date")]
    public DateTime? EndDate { get; set; }

    [Display(Name = "Address Type")]
    public virtual AddressType AddressType { get; set; } = null!;

    public virtual Customer Customer { get; set; } = null!;

}
