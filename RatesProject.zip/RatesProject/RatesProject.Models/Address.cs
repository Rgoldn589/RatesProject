﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RatesProject.Models;

public partial class Address 
{
    public Guid Id { get; set; }

    public Guid CustomerId { get; set; }

    [Required]
    public Guid AddressTypeId { get; set; }

    [Display(Name = "Street")]
    [Required]
    public string StreetAddress { get; set; } = null!;

    [Required]
    public string City { get; set; } = null!;

    [Required]
    public string State { get; set; } = null!;

    [Required]
    public string ZipCode { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    [Display(Name = "Address Type")]
    [NotMapped]
    public List<AddressType>? AddressTypes { get; set; } = new List<AddressType>();

    public virtual AddressType AddressType { get; set; } = null!;

    public virtual Customer Customer { get; set; } = null!;

}
