﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class CustomerRate : IValidatableObject
{
    [Required]
    public Guid Id { get; set; }

    [Required]
    public Guid CustomerId { get; set; }

    [Required]
    public Guid RateTypeId { get; set; }

    [Display(Name = "Rate Name")]
    [Required]
    public string RateName { get; set; } = null!;

    [Display(Name = "Rate Amount")]
    [Required]
    public decimal RateAmount { get; set; }

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "Start Date")]
    [Required]
    public DateTime StartDate { get; set; }

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "End Date")]
    public DateTime? EndDate { get; set; }

    public virtual Customer Customer { get; set; } = null!;

    public virtual RateType RateType { get; set; } = null!;
}
