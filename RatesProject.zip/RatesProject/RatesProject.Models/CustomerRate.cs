﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RatesProject.Models;

public partial class CustomerRate
{
    public Guid Id { get; set; }

    public Guid CustomerId { get; set; }

    [Required]
    public Guid RateTypeId { get; set; }

    [Display(Name = "Rate Name")]
    [Required]
    public string RateName { get; set; } = null!;

    [Display(Name = "Rate Amount")]
    [Required]
    public decimal RateAmount { get; set; }

    public DateTime CreatedDate { get; set; }

    [NotMapped]
    public List<RateType>? RateTypes { get; set; } = new List<RateType>();

    public virtual Customer Customer { get; set; } = null!;

    public virtual RateType RateType { get; set; } = null!;
}
