﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class PhoneType
{
    public Guid Id { get; set; }

    [Display(Name = "Phone Type")]
    public string PhoneTypeDescription { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public virtual ICollection<Phones> Phones { get; set; } = new List<Phones>();
}
