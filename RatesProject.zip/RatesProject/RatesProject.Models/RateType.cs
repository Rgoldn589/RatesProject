﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class RateType
{
    public Guid Id { get; set; }

    [Display(Name = "Description")]
    public string RateTypeDescription { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public virtual ICollection<CustomerRate> CustomerRates { get; set; } = new List<CustomerRate>();
}
