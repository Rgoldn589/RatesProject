﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class RateType
{
    public Guid Id { get; set; }

    [Display(Name = "Description")]
    public string RateTypeDescription { get; set; } = null!;

    public DateTime StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (EndDate < StartDate)
        {
            yield return new ValidationResult(
                errorMessage: "End Date must be greater than Start Date",
                memberNames: new[] { "EndDate" }
           );
        }
    }

    public virtual ICollection<CustomerRate> CustomerRates { get; set; } = new List<CustomerRate>();
}
