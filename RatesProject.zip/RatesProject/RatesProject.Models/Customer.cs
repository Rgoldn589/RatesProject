﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class Customer 
{
    public Guid Id { get; set; }

    [Display(Name = "First Name")]
    [Required]
    public string FirstName { get; set; } = null!;

    [Display(Name = "Last Name")]
    [Required]
    public string LastName { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();

    public virtual ICollection<CustomerRate> CustomerRates { get; set; } = new List<CustomerRate>();

    public virtual ICollection<Phones> Phone { get; set; } = new List<Phones>();
}
