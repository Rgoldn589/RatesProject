﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class Customer
{
    public Guid Id { get; set; }

    [Display(Name = "First Name")]
    [Required]
    public string FirstName { get; set; } = null!;

    [Display(Name = "Last Name")]
    [Required]
    public string LastName { get; set; } = null!;

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "Start Date")]
    [Required]
    public DateTime StartDate { get; set; }

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "End Date")]
    public DateTime? EndDate { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (EndDate < StartDate)
        {
            yield return new ValidationResult(
                errorMessage: "End Date must be greater than Start Date",
                memberNames: new[] { "EndDate" }
           );
        }
    }

    public virtual ICollection<Address> Addresses { get; set; } = new List<Address>();

    public virtual ICollection<CustomerRate> CustomerRates { get; set; } = new List<CustomerRate>();

    public virtual ICollection<Phones> Phone { get; set; } = new List<Phones>();
}
