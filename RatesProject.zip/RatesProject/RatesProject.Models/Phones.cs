﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models;

public partial class Phones
{
    [Required]
    public Guid Id { get; set; }

    [Required]
    public Guid CustomerId { get; set; }

    [Required]
    public Guid PhoneTypeId { get; set; }

    [DisplayFormat(DataFormatString = "{0:(###) ###-####}")]
    [Display(Name = "Phone Number")]
    [Required]
    public string PhoneNumber { get; set; } = null!;

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "Start Date")]
    [Required]
    public DateTime StartDate { get; set; }

    [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
    [Display(Name = "End Date")]
    public DateTime? EndDate { get; set; }

    public virtual Customer Customer { get; set; } = null!;

    public virtual PhoneType PhoneType { get; set; } = null!;
}
