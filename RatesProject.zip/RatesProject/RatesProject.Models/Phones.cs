﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RatesProject.Models;

public partial class Phones
{
    [Required]
    public Guid Id { get; set; }

    [Required]
    public Guid CustomerId { get; set; }

    [Display(Name = "Phone Type")]
    [Required]
    public Guid PhoneTypeId { get; set; }

    [DisplayFormat(DataFormatString = "{0:(###) ###-####}")]
    [Display(Name = "Phone Number")]
    [Required]
    public string PhoneNumber { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    [NotMapped]
    public List<PhoneType>? PhoneTypes { get; set; } = new List<PhoneType>();

    public virtual Customer Customer { get; set; } = null!;

    public virtual PhoneType PhoneType { get; set; } = null!;
}
