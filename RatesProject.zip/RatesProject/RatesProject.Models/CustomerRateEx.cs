﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RatesProject.Models
{
    public partial class CustomerRate : IValidatableObject
    {
        [NotMapped]
        public List<RateType>? RateTypes { get; set; } = new List<RateType>();

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (EndDate < StartDate)
            {
                yield return new ValidationResult(
                    errorMessage: "End Date must be greater than Start Date",
                    memberNames: new[] { "EndDate" }
               );
            }
        }
    }
}
