﻿using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models
{
    public class Rate
    {

        [Required]
        public int Id { get; set; }

        [Display(Name = "Rates")]
        [Required]
        public string Name { get; set; }    
    }
}
