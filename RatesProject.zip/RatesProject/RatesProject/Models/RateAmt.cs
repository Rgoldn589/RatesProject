﻿using System.ComponentModel.DataAnnotations;

namespace RatesProject.Models
{
    public class RateAmt
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public Rate Rate { get; set; }

        [Display(Name = "Rate Amt 1")]
        [Required]
        public decimal RateAmount1 { get; set; }

        [Display(Name = "Rate Amt 2")]
        [Required]
        public decimal RateAmount2 { get; set; }

        [Display(Name = "Rate Amt 3")]
        [Required]
        public decimal RateAmount3 { get; set; }

        [Display(Name = "Rate Amt 4")]
        [Required]
        public decimal RateAmount4 { get; set; }

        [Display(Name = "Rate Amt 5")]
        [Required]
        public decimal RateAmount5 { get; set; }
    }
}
