﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RatesProject.API.Requests;
using RatesProject.Models;
using RatesProject.Services;
using System.Net;

namespace RatesProject.Controllers
{
    public class CustomerAddressesController : Controller
    {
        public async Task<IActionResult> Index()
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerAddress/GetCustomerCustomerAddresses");
            var customerAddresses = new List<Address>(JsonConvert.DeserializeObject<List<Address>>(result));
            return View(customerAddresses);
        }

        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrieveCustomerAddress(id));
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }


        // GET: Address/Create
        public async Task<IActionResult> Create(Guid id)
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerAddress/GetAddressTypes");
            var addressTypes = new List<AddressType>(JsonConvert.DeserializeObject<List<AddressType>>(result));
            var customerAddress = new Address()
            {
                CustomerId = id,
                StartDate = DateTime.Now,
                AddressTypes = addressTypes
            };

            return View(customerAddress);
        }

        // POST: Address/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id, AddressTypeId, CustomerId, StreetAddress, City, State, ZipCode, StartDate,EndDate")] Address address)
        {
            await UpdateCustomerAddress(address);
            ModelState.Clear();
            return View();
        }

        // GET: Address/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {
            return View(await RetrieveCustomerAddress(id));
        }

        // POST: Address/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id, CustomerId, AddressTypeId, StreetAddress, City, State, ZipCode, StartDate, EndDate")] Address address)
        {
            await UpdateCustomerAddress(address);
            return RedirectToAction("Details", "Customer", new { id = address.CustomerId });
        }

        // GET: Address/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {

            return View(await RetrieveCustomerAddress(id));
        }

        // POST: Address/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid customerId)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "CustomerAddress/DeleteCustomerAddress", json);
            return RedirectToAction("Details", "Customer", new { id = customerId });
        }

        public void Customer(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Customer/Details?id=" + id);
        }

        public RedirectToActionResult ToAction(Guid id, string actionName, string control)
        {
            return RedirectToAction(control, actionName, new { id });
        }

        private async Task UpdateCustomerAddress(Address address)
        {
            var request = new UpdateCustomerAddressRequest()
            {
                Id = address.Id == Guid.Empty ? Guid.NewGuid() : address.Id,
                AddressTypeId = address.AddressTypeId,        
                CustomerId = address.CustomerId,
                StreetAddress = address.StreetAddress,
                City = address.City,
                State = address.State,
                ZipCode = address.ZipCode,
                StartDate = address.StartDate,
                EndDate = address.EndDate
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "CustomerAddress/UpdateCustomerAddress", json);
        }

        private async Task<Address> RetrieveCustomerAddress(Guid id)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerAddress/GetCustomerAddress", json);
            var customerAddress = JsonConvert.DeserializeObject<Address>(result);
            return customerAddress;
        }

        public RedirectToActionResult BackToList(Guid id)
        {
            return RedirectToAction("Details", "Customer", new { id });
        }
    }
}
