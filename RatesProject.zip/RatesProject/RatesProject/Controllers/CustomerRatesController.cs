﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RatesProject.API.Requests;
using RatesProject.Models;
using RatesProject.Services;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Numerics;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace RatesProject.Controllers
{
    public class CustomerRatesController : Controller
    {
        public async Task<IActionResult> Index()
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerRate/GetCustomerRates");
            var customerRates = new List<CustomerRate>(JsonConvert.DeserializeObject<List<CustomerRate>>(result));
            return View(customerRates);
        }

        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrieveCustomerRate(id));
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }

        // GET: CustomerRate/Create
        public async Task<IActionResult> Create(Guid id)
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerRate/GetRateTypes");
            var rateTypes = new List<RateType>(JsonConvert.DeserializeObject<List<RateType>>(result));
            CustomerRate customerRate  = new CustomerRate()
            {
                CustomerId = id,
                RateTypes = rateTypes
            };

            return View(customerRate);
        }

        // POST: CustomerRate/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id, RateTypeID, CustomerID, RateName, RateAmount, StartDate, EndDate")] CustomerRate rate)
        {

            ModelState.Remove(nameof(CustomerRate.Customer));
            ModelState.Remove(nameof(CustomerRate.RateType));

            if (!ModelState.IsValid)
            {
                return View(rate);
            }

            await UpdateCustomerRate(rate);
            ModelState.Clear();
            return View();
        }

        // GET: CustomerRate/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {

            return View(await RetrieveCustomerRate(id));
        }

        // POST: CustomerRate/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit([Bind("Id,RateTypeId,CustomerId,RateName,RateAmount,StartDate,EndDate")] CustomerRate rate)
        {
      
            ModelState.Remove(nameof(CustomerRate.Customer));
            ModelState.Remove(nameof(CustomerRate.RateType));

            if (!ModelState.IsValid)
            {
                return View(rate);
            }

            await UpdateCustomerRate(rate);
            return RedirectToAction("Details", "Customer", new { id = rate.CustomerId });
        }

        // GET: CustomerRate/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {
            return View(await RetrieveCustomerRate(id));
        }

        // POST: CustomerRate/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid customerId)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "CustomerRate/DeleteCustomerRate", json);
            return RedirectToAction("Details", "Customer", new { id = customerId });
        }

        public void Customer(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Customer/Details?id=" + id);
        }

        public RedirectToActionResult ToAction(Guid id, string actionName, string control)
        {
            return RedirectToAction(control, actionName, new { id });
        }

        private async Task UpdateCustomerRate(CustomerRate rate)
        {
            var request = new UpdateCustomerRateRequest()
            {
                Id = rate.Id == Guid.Empty ? Guid.NewGuid() : rate.Id,
                RateTypeId = rate.RateTypeId,
                CustomerId = rate.CustomerId,
                RateName = rate.RateName,
                RateAmount = rate.RateAmount
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "CustomerRate/UpdateCustomerRate", json);
        }

        private async Task<CustomerRate> RetrieveCustomerRate(Guid id)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerRate/GetCustomerRate", json);
            var customerRate = JsonConvert.DeserializeObject<CustomerRate>(result);
            return customerRate;
        }

        public RedirectToActionResult BackToList(Guid id)
        {
            return RedirectToAction("Details", "Customer", new { id });
        }
    }
}
