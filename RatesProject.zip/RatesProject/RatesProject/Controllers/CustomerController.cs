using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RatesProject.Models;
using RatesProject.Services;
using RatesProject.API.Requests;
using System.Diagnostics;

namespace RatesProject.Controllers
{
    public class CustomerController : Controller
    {
  
        public async Task<IActionResult> Index()
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "Customer/GetCustomers");
            var customer = new List<Customer>(JsonConvert.DeserializeObject<List<Customer>>(result));
            return View(customer);
        }

        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrieveCustomer(id));
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }


        // GET: Customer/Create
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FirstName,LastName,StartDate,EndDate")] Customer customer)
        {
            await UpdateCustomer(customer);
            return View();
        }

        // GET: Customer/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {
            return View(await RetrieveCustomer(id));
        }

        // POST: Customer/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,FirstName,LastName,StartDate,EndDate")] Customer customer)
        {
            await UpdateCustomer(customer);
            return RedirectToAction(nameof(Index));
        }

        // GET: Customer/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {
            return View(await RetrieveCustomer(id));
        }

        // POST: Customer/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "Customer/DeleteCustomer", json);
            return RedirectToAction(nameof(Index));
        }

        public void Customer(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Customer/Details?id=" + id);
        }

        public RedirectToActionResult ToAction(Guid id, string actionName, string control)
        {
            return RedirectToAction(control, actionName, new { id });
        }

        private async Task UpdateCustomer(Customer customer)
        {
            var request = new UpdateCustomerRequest()
            {
                ID = customer.Id == Guid.Empty ? Guid.NewGuid() : customer.Id,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "Customer/UpdateCustomer", json);
        }

        private async Task<Customer> RetrieveCustomer(Guid id)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "Customer/GetCustomer", json);
            var customer = JsonConvert.DeserializeObject<Customer>(result);   
            return customer;
        }
    }

}

