using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RatesProject.Models;

namespace RatesProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View(CreateData());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private List<RateAmt> CreateData()
        {

            List<RateAmt> rates = new List<RateAmt>();

            rates.Add(new RateAmt
            {
                Id = 100,
                Rate = new Rate()
                {
                    Id = 200,
                    Name = "Rate 1"

                },

                RateAmount1 = 5.1m,
                RateAmount2 = 5.2m,
                RateAmount3 = 5.3m,
                RateAmount4 = 5.4m,
                RateAmount5 = 5.5m,
            });

            rates.Add(new RateAmt
            {
                Id = 100,
                Rate = new Rate()
                {
                    Id = 200,
                    Name = "Rate 2"

                },

                RateAmount1 = 6.1m,
                RateAmount2 = 6.2m,
                RateAmount3 = 6.3m,
                RateAmount4 = 6.4m,
                RateAmount5 = 6.5m,
            });

            rates.Add(new RateAmt
            {
                Id = 100,
                Rate = new Rate()
                {
                    Id = 200,
                    Name = "Rate 3"

                },

                RateAmount1 = 7.1m,
                RateAmount2 = 7.2m,
                RateAmount3 = 7.3m,
                RateAmount4 = 7.4m,
                RateAmount5 = 7.5m,
            });

            rates.Add(new RateAmt
            {
                Id = 100,
                Rate = new Rate()
                {
                    Id = 200,
                    Name = "Rate 4"

                },

                RateAmount1 = 8.1m,
                RateAmount2 = 8.2m,
                RateAmount3 = 8.3m,
                RateAmount4 = 8.4m,
                RateAmount5 = 8.5m,
            });

            rates.Add(new RateAmt
            {
                Id = 100,
                Rate = new Rate()
                {
                    Id = 200,
                    Name = "Rate 5"

                },

                RateAmount1 = 9.1m,
                RateAmount2 = 9.2m,
                RateAmount3 = 9.3m,
                RateAmount4 = 9.4m,
                RateAmount5 = 9.5m,
            });

           return rates;
        }
    }
}
