﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RatesProject.API.Requests;
using RatesProject.Models;
using RatesProject.Services;
using System.Net;
using System.Numerics;
using static Google.Protobuf.WellKnownTypes.Field.Types;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace RatesProject.Controllers
{
    public class CustomerPhoneNumbersController : Controller
    {
        public async Task<IActionResult> Index()
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerPhone/GetCustomerPhones");
            var customerPhones = new List<Phones>(JsonConvert.DeserializeObject<List<Phones>>(result));
            return View(customerPhones);
        }

        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrieveCustomerPhone(id));
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }


        // GET: CustomerPhone/Create
        public async Task<IActionResult> Create(Guid id)
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerPhone/GetPhoneTypes");
            var phoneTypes = new List<PhoneType>(JsonConvert.DeserializeObject<List<PhoneType>>(result));
            var phone = new Phones()
            {
                CustomerId = id,
                PhoneTypes = phoneTypes
            };
            return View(phone);
        }

        // POST: CustomerPhone/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( [Bind("Id, PhoneTypeID, CustomerID, PhoneNumber, StartDate, EndDate")] Phones phone)
        {
            await UpdateCustomerPhone(phone);
            return View();
        }

        // GET: CustomerPhone/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {
            return View(await RetrieveCustomerPhone(id));
        }

        // POST: CustomerPhone/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id, PhoneTypeId, CustomerId, PhoneNumber, StartDate, EndDate")] Phones phone)
        {
            await UpdateCustomerPhone(phone);
            return RedirectToAction("Details", "Customer", new { id = phone.CustomerId });
        }

        // GET: CustomerPhone/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {
            return View(await RetrieveCustomerPhone(id));
        }

        // POST: CustomerPhone/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid customerId)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "CustomerPhone/DeleteCustomerPhone", json);
            return RedirectToAction("Details", "Customer", new { id = customerId });
        }

        public void Customer(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Customer/Details?id=" + id);
        }

        public RedirectToActionResult ToAction(Guid id, string actionName, string control)
        {
            return RedirectToAction(control, actionName, new { id });
        }

        private async Task UpdateCustomerPhone(Phones phone)
        {
            var request = new UpdateCustomerPhoneRequest()
            {
                Id = phone.Id == Guid.Empty ? Guid.NewGuid() : phone.Id,
                PhoneTypeId = phone.PhoneTypeId,
                CustomerId = phone.CustomerId,
                PhoneNumber = phone.PhoneNumber
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "CustomerPhone/UpdateCustomerPhone", json);
        }

        private async Task<Phones> RetrieveCustomerPhone(Guid id)
        {
            var request = new GetCustomerDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "CustomerPhone/GetCustomerPhone", json);
            var customerPhone = JsonConvert.DeserializeObject<Phones>(result);
            return customerPhone;
        }

        public RedirectToActionResult BackToList(Guid id)
        {
            return RedirectToAction("Details", "Customer", new { id });
        }
    }
}

